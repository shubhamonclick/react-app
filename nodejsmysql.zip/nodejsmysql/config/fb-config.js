module.exports = {
    clientID: '576014989750467',
    clientSecret: '16fbc4b43ede7b526157011ee5257771',
    callbackURL: 'http://localhost:4000/facebook/callback'
}