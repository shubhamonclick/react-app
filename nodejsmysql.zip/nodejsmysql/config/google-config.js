module.exports={
    clientId: '966019473572-uk5fm0qf56800me5r7sj4j7c0acmcdn4.apps.googleusercontent.com',
    secret: "sfbcha7i2dLCiwuI-RGGpCJF",
    redirect: "http://localhost:4000/google/login/callback"
}