const authJwt = require("./authjwt");
const verifySignUp = require("./verifySignup");

module.exports = {
  authJwt,
  verifySignUp
};