const { sequelize, Sequelize } = require(".");

module.exports = (sequelize, Sequelize) => {
    const Google  = sequelize.define('google', {
        name: {
            type: Sequelize.STRING,
        },
        // email: {
        //     type: Sequelize.STRING
        // },
        googleId: {
            type: Sequelize.STRING
        }
    });

    return Google
}