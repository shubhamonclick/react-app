const { sequelize, Sequelize } = require(".");

module.exports = (sequelize, Sequelize) => {
    const Facebook  = sequelize.define('facebook', {
        name: {
            type: Sequelize.STRING,
        },
        // email: {
        //     type: Sequelize.STRING
        // },
        facebookId: {
            type: Sequelize.STRING
        }
    });

    return Facebook
}