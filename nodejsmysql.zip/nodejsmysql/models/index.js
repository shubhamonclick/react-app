const  Sequelize  = require('sequelize');
const config = require('../config/db.config');

//  Passing a connection 
const sequelize = new Sequelize(config.DB, config.USER, config.PASSWORD, {
    host: config.HOST,
    dialect: config.dialect,
    operatorsAliases: false,

    pool: {
        min: config.pool.min,
        max: config.pool.max,
        acquire: config.pool.acquire,
        idle: config.pool.idle
    }
});
const db = {};
db.tutorials = require("./tutorial.model.js")(sequelize, Sequelize);
db.auth = require("./auth.model.js")(sequelize, Sequelize);
db.google = require("./google.model.js")(sequelize, Sequelize);
db.facebook = require("./fb.model.js")(sequelize, Sequelize);
db.Sequelize = Sequelize;
db.sequelize = sequelize;

module.exports = db;

try {
    sequelize.authenticate();
    console.log('Connection has been established successfully.');
} catch (error) {
    console.error('Unable to connect to the database:', error);
}