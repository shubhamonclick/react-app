const express = require('express');
const app = express();
const cors = require('cors');
const port = 4000;
const bodyParser = require('body-parser');
const passport = require('passport');
const cookieSession = require('cookie-session')
const authRoute = require('./routes/auth.routes')
const tutorialRouter = require('./routes/tutorial.routes')
const googleRouter = require('./routes/google_auth.routes')
const fbRouter = require('./routes/fb_auth.routes')
const profileRouter = require('./routes/profile.routes')
require('./passport_setup/passport_google_setup');
require('./passport_setup/passport_fb_setup')


// Middlewares
app.use(bodyParser.json());
app.use(express.json());
app.use(cookieSession({
    name: 'google-session',
    keys: ['key1', 'key2']
}))
app.use(cors());
app.use(passport.initialize());
app.use(passport.session());




//Routes Middleware
app.get('/api', (req, res) => {
    res.send('welcome to localhost:4000')
})
app.use('/api/auth', authRoute);
app.use('/api/tutorials', tutorialRouter);
app.use('/google', googleRouter);
app.use('/facebook', fbRouter);
app.use('/profile', profileRouter);


app.listen(port, () => console.log(`app listening on port ${port}...!`))