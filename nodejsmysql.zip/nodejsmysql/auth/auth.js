const jwt = require('jsonwebtoken');
const path = require("path");
const config = require('../config/auth.config');
const auth = require('../models/auth.model')

function newauth(req, res, next) {
    const token = req.header('x-access-token');
    if (!token) {
        // console.log('Error no token');
        // return res.status(200).json({
        //     code : 599,
        //     message : 'Access denied. No token found.',
        //     data : []
        // });
        next();
    }
    else {
        try {
            const decoded = jwt.verify(token, config.jwt_secret_exp);
            req.body.email = decoded.email;

            auth.findOne({ id: req.body.id }, function (err, doc) {
                if (err) {
                    return res.status(200).json({
                        code: 599,
                        message: 'User not found.',
                        data: []
                    });
                }

                req.user = doc;
                next();
            });
        }
        catch (err) {
            console.log(err, 'Error session out');
            return res.status(200).json({
                code: 599,
                message: 'Session timedout.',
                data: []
            });
        }
    }
}
module.exports = newauth;