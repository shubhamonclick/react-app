const router = require('express').Router();
const passport = require('passport')


router.get('/failed', (req, res) => {
    res.send('login failed')
})

router.get('/good', (req, res) => {
    console.log('name', req.user.name);
    res.send(`welcome  ${req.user.name}!`)
})

router.get('/',
    passport.authenticate('facebook',{scope:'email'}));

router.get('/callback',
    passport.authenticate('facebook', { failureRedirect: '/facebook/failed' }),
    function (req, res) {
        // Successful authentication, redirect home.
        res.redirect('/facebook/good');
    });


module.exports = router;