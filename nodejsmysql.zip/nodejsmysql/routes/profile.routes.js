const router = require('express').Router();

const authCheck = (req, res, next) => {
    if(!req.user){
        res.redirect('/google/login')
    }else{
        next()
    }
}


router.get('/',authCheck, (req, res) => {
    console.log('name', req.user);
    res.send(`welcome ${req.user.name}! <a href="/google/logout">logout</a>`)
})



module.exports = router;