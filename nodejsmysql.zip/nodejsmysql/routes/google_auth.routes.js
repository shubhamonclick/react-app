const router = require('express').Router();
const passport = require('passport')


router.get('/logout', (req, res) => {
    req.logOut();
    res.redirect('/api/')
})

router.get('/failed', (req, res) => {
    res.send('login failed')
})


router.get('/login',
    passport.authenticate('google', { scope: ['profile', 'email'] }));

router.get('/login/callback',
    passport.authenticate('google', { failureRedirect: '/google' }),
    function (req, res) {
        
        // Successful authentication, redirect home.
        res.redirect('/profile');
    });


module.exports = router;