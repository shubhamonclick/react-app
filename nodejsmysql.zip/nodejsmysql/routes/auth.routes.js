const router = require('express').Router(); 
const auth = require('../controllers/auth.controller')
const verifySignUp  = require("../middlewares/verifySignup");
const {authJwt} = require('../middlewares/authjwt')

router.post('/register',[verifySignUp.verifySignUp], auth.register);
router.post('/login', auth.login)
router.get('/profile',authJwt,auth.profile)


module.exports = router;