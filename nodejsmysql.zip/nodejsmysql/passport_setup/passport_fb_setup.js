const passport = require('passport')
const FacebookStrategy = require('passport-facebook').Strategy;
const config = require('../config/fb-config');
const db = require('../models');
const User = db.facebook;

passport.serializeUser((user, done) => {
    console.log(user);
    done(null, user)
})

passport.deserializeUser((id, done) => {
    done(null, id)
})

passport.use(new FacebookStrategy({
    clientID: config.clientID,
    clientSecret: config.clientSecret,
    callbackURL: config.callbackURL
},
    function (accessToken, refreshToken, profile, done) {

        User.findOne({
            where: { facebookId: profile.id, name: profile.displayName }
        }).then(user =>  {
            console.log(profile, "------");
            console.log(user, "------");
            if (user != undefined || user != null) {
                done(null, user);
            } else {
                var userData = {
                    facebookId: profile.id,
                    name: profile.displayName,
                    created: Date.now()
                };
                User.create({ facebookId: profile.id, name: profile.displayName }).then(data => {
                    console.log('inside created then', userData);
                    return done(null, userData);
                }).catch(err => {
                    return done(null, false, { message: err + " !!! Please try again" });
                });
            }
        });
    }

));