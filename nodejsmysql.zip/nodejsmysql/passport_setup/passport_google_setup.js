const passport = require('passport')
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const config = require('../config/google-config');
const db = require('../models');
const User = db.google;

passport.serializeUser((user, done) => {
    console.log(user);
    done(null, user)
})

passport.deserializeUser((id, done) => {
    done(null, id)
})


passport.use(new GoogleStrategy({
    clientID: config.clientId,
    clientSecret: config.secret,
    callbackURL: config.redirect
},
   

    function (accessToken, refreshToken, profile, done) {

        console.log(profile);
       
        User.findOne({ where: { googleId: profile.id, name: profile.displayName } }).then(user => {
            console.log(profile, '--->');
            console.log(user, 'user');
            if (user != undefined || user != null) {
                console.log('inside if');
                return done(null, user, { message: "User " });
            } else {
                console.log('inside else', profile);
                var username = profile.displayName.split(' ');
                console.log(profile.emails[0].value,profile.photos[0].value);
                var userData = {
                    name: profile.displayName,
                    username: username[0],
                    // password: username[0],
                    googleId: profile.id,
                    email: profile.emails[0].value,
                    picture: profile.photos[0].value,
                };
                // send email to user just in case required to send the newly created
                // credentails to user for future login without using google login
                User.create({ googleId: profile.id, name: profile.displayName }).then(data => {
                    console.log('inside created then', userData);
                    return done(null, userData);
                }).catch(err => {
                    return done(null, false, { message: err + " !!! Please try again" });
                })
            }
        }).catch(err => {
            return done(null, false, { message: err + " !!! Please try again- out" });
        })
    }
));