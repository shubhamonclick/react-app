import React, { useState, useEffect } from 'react';
import axios from "axios";

export function Profile() {
  const token = localStorage.getItem('currentUser');

  const [data, setData] = useState([]);

  useEffect(() => {
    loadProfile();
  }, []);


  const loadProfile = async () => {
    const result = await axios.get(`http://localhost:4000/api/auth/profile`,
      { headers: { 'x-access-token': token } });

    setData(result.data)
  }

  console.log(data)
  return (
    <div className="container-fluid my-5">
      <p>Profile Id: {data.id}</p>
      <p>Name: {data.username}</p>
      <p>Email: {data.email}</p>
    </div>
  )
}