import React, { useState } from "react";
import axios from "axios";
import { useHistory, Link } from 'react-router-dom';
export function Login() {

    // let loggedin = false;
    const history = useHistory();
    const [user, setUser] = useState({
        username: '',
        password: ''
    });

    const { username, password } = user;
    const onChange = e => {
        setUser({ ...user, [e.target.name]: e.target.value });
    }


    const onSubmit = async e => {
        e.preventDefault();
        await axios.post(`http://localhost:4000/api/auth/login/`, user)
        .then(function (response) {
            // console.log(response.data.accessToken);
            if (response.status === 200 ) {
                if(response.data && response.data.accessToken.length>0){
                    localStorage.setItem('currentUser', JSON.stringify(response.data.accessToken));
                    localStorage.setItem('id', JSON.stringify(response.data.id));
                    history.push('/content')
                }
            }
        })
        .catch(function (err) {
            console.log(err , 'errrr');
        });
    }

    return (
        <div className="container">
            <h1>Login</h1>
            <form onSubmit={e => onSubmit(e)}>
                <div className="form-group">
                    <label>Username</label>
                    <input type="text" className="form-control" name="username" value={username} onChange={e => onChange(e)} placeholder="" />
                </div>
                <div className="form-group">
                    <label>Password</label>
                    <input type="password" className="form-control" name="password" value={password} onChange={e => onChange(e)} placeholder="" />
                </div>

                <button type="submit" className="btn btn-primary">Submit</button><Link to="/register" className="ml-5 btn btn-primary">Register</Link>
            </form>
            <div>
               
            </div>
        </div>
    )

}