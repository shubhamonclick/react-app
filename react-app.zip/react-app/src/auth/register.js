import React, { useState } from "react";
import axios from "axios";
import { useHistory, Link } from 'react-router-dom';
export function Register() {

    const history = useHistory();
    const [user, setUser] = useState({
        username: '',
        email: '',
        password: ''
    });

    const { username, email, password } = user;
    const onChange = e => {
        e.preventDefault();
        setUser({ ...user, [e.target.name]: e.target.value });
    }


    const onSubmit = async e => {
        e.preventDefault();
        await axios.post(`http://localhost:4000/api/auth/register/`, user);
        history.push('/')
    }


    return (
        <div className="container">
            <h1>Register</h1>
            <form onSubmit={e => onSubmit(e)}>
                <div className="form-group">
                    <label>Username</label>
                    <input type="text" className="form-control" name="username" value={username} onChange={e => onChange(e)} placeholder="" />
                </div>
                <div className="form-group">
                    <label>E-mail</label>
                    <input type="email" className="form-control" name="email" value={email} onChange={e => onChange(e)} placeholder="" />
                </div>
                <div className="form-group">
                    <label>Password</label>
                    <input type="password" className="form-control" name="password" value={password} onChange={e => onChange(e)} placeholder="" />
                </div>

                <button type="submit" className="btn btn-primary">Submit</button>
                <Link to="/" className="ml-5 btn btn-primary">Login</Link>
            </form>
        </div>
    )

}