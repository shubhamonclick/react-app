import React from 'react'
import { Redirect, Route } from 'react-router-dom'


export function SecuredRoute(props) {
    console.log(props);
    let currentUser = localStorage.getItem('currentUser')
    return (
        <Route path={props.path} render={data => currentUser ? (
            <props.component {...data}></props.component>) :
            (<Redirect to={{ pathname: '/' }}></Redirect>)}></Route>
    )
}


