import React from 'react';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import { ViewTut } from './tutorials/view';
import { Switch, Route, useHistory, useLocation } from 'react-router-dom';
import { AllTut } from './tutorials/allTuts';
import { AddTut } from './tutorials/addTuts';
import { EditTut } from './tutorials/editTuts';
import { Register } from './auth/register';
import { Login } from './auth/login';
import Home from './Homepage/homepage';
import { Profile } from './auth/profile';
import { SecuredRoute } from './auth/protectedRoute';


function App() {

let history = useHistory();
let location = useLocation();
  const logout = () => {
   return ( (localStorage.getItem('currentUser')) ?
        <button onClick={() => {localStorage.clear(); history.push('/')}} className="btn btn-info">Logout</button>
        : null
    )
  }
  console.log(location);
  return (
    <div className="App">
      {(location.pathname === '/')? null :(logout())}
     
      <Switch>
        <Route path='/register' exact component={Register} />
        <Route path='/' exact component={Login} />

        <SecuredRoute path='/profile' exact component={Profile} />
        <SecuredRoute path='/content' exact component={Home} />
        <SecuredRoute path='/tutorials' exact component={AllTut} />
        <SecuredRoute path='/tutorials/add' exact component={AddTut} />
        <SecuredRoute path='/tutorials/edit/:id' exact component={EditTut} />
        <SecuredRoute path='/tutorials/view/:id' exact component={ViewTut} />

      </Switch>
    </div>
  );
}

export default App;
