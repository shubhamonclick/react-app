import React from 'react';
import { Link } from 'react-router-dom';

const  Home = () => {

    return (
        <div className="container-fluid my-5">
            <Link to={`/tutorials`} className="btn btn-info">Tutorials</Link>
        </div>
    )
}

export default Home