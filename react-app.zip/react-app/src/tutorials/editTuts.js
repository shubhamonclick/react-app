import React, { useState, useEffect } from "react";
import axios from "axios";
import { useHistory, useParams } from 'react-router-dom';
export function EditTut() {

    const { id } = useParams();
    const history = useHistory();
    const [tuts, setTuts] = useState({
        title: '',
        description: '',
        published: false
    });

    useEffect(() => {
        loadTuts()
    }, []);

    const loadTuts = async () => {
        const result = await axios.get(`http://localhost:4000/api/tutorials/${id}`);
        setTuts(result.data)
    }

    const { title, description, published } = tuts;
    const onChange = e => {
        setTuts({ ...tuts, [e.target.name]: e.target.value });
    }


    const onSubmit = async e => {
        e.preventDefault();
        await axios.put(`http://localhost:4000/api/tutorials/${id}`, tuts);
        history.push('/tutorials')
    }

    console.log(tuts);
    return (
        <div className="container">
            <h1>Edit Tutorial</h1>
            <form onSubmit={e => onSubmit(e)}>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" class="form-control" name="title" value={title} onChange={e => onChange(e)} placeholder="" />
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <input type="text" class="form-control" name="description" value={description} onChange={e => onChange(e)} placeholder="" />
                </div>
                <div class="form-group">
                    <label>Published</label>
                    <input type="text" class="form-control" name="published" value={published} onChange={e => onChange(e)} placeholder="" />
                </div>

                <button type="submit" className="btn btn-primary">Submit</button>
            </form>
        </div>
    )

}