import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from 'react-router-dom';
export function ViewTut() {

    const token = localStorage.getItem('currentUser');
    const { id } = useParams();
    const [tuts, setTuts] = useState([]);

    useEffect(() => {
        loadTuts()
    }, []);

    const loadTuts = async () => {
        const result = await axios.get(`http://localhost:4000/api/tutorials/${id}`,
        { headers: { 'x-access-token': token } });
        setTuts(result.data)
    }

    console.log(tuts);
    return (
        <div className="container">
            <h1>View Tutorial</h1>
            <ul className="list-group">
                <li className="list-group-item">{id}</li>
                <li className="list-group-item">{tuts.title}</li>
                <li className="list-group-item">{tuts.description}</li>
                <li className="list-group-item">{tuts.published ? `true` : `false`}</li>
            </ul>
        </div>
    )

}