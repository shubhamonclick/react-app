import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from 'react-router-dom';

export function AllTut() {

  const [tuts, setTuts] = useState([]);
  const [published, setPublished] = useState([]);

  useEffect(() => {
    loadTuts();
  }, []);
  useEffect(() => {
    loadPublished();
  }, []);

  const loadTuts = async () => {
    const result = await axios.get(`http://localhost:4000/api/tutorials/`);
    setTuts(result.data)
  }

  const loadPublished = async () => {
    const result = await axios.get(`http://localhost:4000/api/tutorials/published`);
    setPublished(result.data)
  }

  const deleteTut = async (id) => {
    await axios.delete(`http://localhost:4000/api/tutorials/${id}`);
    loadTuts();
  }

  const deleteAllTut = async () => {
    await axios.delete(`http://localhost:4000/api/tutorials/`);
    loadTuts();
  }
  console.log(published);
  return (
    <div className="container-fluid my-5">
      <Link className="btn btn-primary" to="/tutorials/add" >Add Tutorial</Link>

      <h1>All Tutorials</h1>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Description</th>
            <th scope="col">Published</th>
            <th scope="col" colSpan="3">Actions 
            <button type="button" onClick={() => deleteAllTut()} className="btn btn-danger ml-2">Delete All Tutorials</button></th>
          </tr>
        </thead>
        <tbody>
          {tuts.map(tut => (
            <tr key={tut.id}>
              <th scope="row">{tut.id}</th>
              <td>{tut.title}</td>
              <td>{tut.description}</td>
              {tut.published ? <td>true</td> : <td>false</td>}
              <td><Link to={`/tutorials/view/${tut.id}`} className="btn btn-primary">View</Link></td>
              <td><Link to={`/tutorials/edit/${tut.id}`} className="btn btn-info">Edit</Link></td>
              <td><button type="button" onClick={() => deleteTut(tut.id)} className="btn btn-danger">Delete</button></td>
            </tr>
          ))}
        </tbody>
      </table>
      <hr></hr>
      <div className="row justify-content-between">
        <div className="col-md-6 table-responsive">
          <h2>Published Tutorials</h2>
          <table className="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Description</th>
                <th scope="col">Published</th>
                <th scope="col" colSpan="3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {published.map(tut => (
                <tr key={tut.id}>
                  <th scope="row">{tut.id}</th>
                  <td>{tut.title}</td>
                  <td>{tut.description}</td>
                  {tut.published ? <td>true</td> : <td>false</td>}
                  <td><Link to={`/tutorials/view/${tut.id}`} className="btn btn-primary">View</Link></td>
                  <td><Link to={`/tutorials/edit/${tut.id}`} className="btn btn-info">Edit</Link></td>
                  <td><button type="button" onClick={() => deleteTut(tut.id)} className="btn btn-danger">Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <hr></hr>
        </div>
        <div className="col-md-6 table-responsive">
          <h2>Drafted Tutorials</h2>
          <table className="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Description</th>
                <th scope="col">Published</th>
                <th scope="col" colSpan="3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {tuts.map(tut => (
                tut.published ? null
                :  <tr key={tut.id}>
                  <th scope="row">{tut.id}</th>
                  <td>{tut.title}</td>
                  <td>{tut.description}</td>
                  {tut.published ? <td>true</td> : <td>false</td>}
                  <td><Link to={`/tutorials/view/${tut.id}`} className="btn btn-primary">View</Link></td>
                  <td><Link to={`/tutorials/edit/${tut.id}`} className="btn btn-info">Edit</Link></td>
                  <td><button type="button" onClick={() => deleteTut(tut.id)} className="btn btn-danger">Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <hr></hr>
        </div>
      </div>
    </div>
  )

}